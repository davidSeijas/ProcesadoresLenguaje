package ast;


public abstract class Expresion extends Instruccion{
    //esta es vacia
}
