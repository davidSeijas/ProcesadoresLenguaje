package ast;

public class InsBart extends Instruccion{
    //no hace nada
    public String toString(){
        return "Bartolo";
    }

    public void vincula(){}
    public void chequea(){}

    @Override
    public String generaCodigo() {
        // TODO Auto-generated method stub
        return "";
    }

    @Override
    public void delta() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void memoria() {
        // TODO Auto-generated method stub
        
    }
}
