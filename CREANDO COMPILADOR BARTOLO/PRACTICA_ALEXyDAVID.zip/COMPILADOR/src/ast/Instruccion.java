package ast;


public abstract class Instruccion extends Nodo{
    //va vacia
}
